# SBB Market 3D — Web Gratis

Aplikasi web/PWA 100% gratis untuk penggunaan lokal/offline-first.

## Fitur
- Login Admin, Kasir, Pembeli
- Dashboard
- Data barang & stok
- Penjualan/checkout
- Data pembeli
- Data penjual/supplier
- Keuangan: omzet, HPP, pengeluaran, laba bersih
- Laporan & export CSV
- Tampilan 3D CSS
- Mini game Tebak Harga dengan koin non-tunai
- PWA / Add to Home Screen
- Offline cache melalui Service Worker

## Akun demo
- Admin: admin / admin123
- Kasir: kasir / kasir123
- Pembeli: pembeli / pembeli123

## Cara menjalankan di komputer
Karena Service Worker perlu HTTP/HTTPS, jangan hanya double-click file bila ingin mode PWA penuh.

Dengan Python:
`python -m http.server 8080`

Lalu buka `http://localhost:8080`.

## Hosting gratis
Cocok untuk Cloudflare Pages sebagai static site. Unggah folder ini atau hubungkan repository Git.

## Catatan penting
Versi ini menyimpan data di localStorage browser. Artinya data berada di perangkat/browser yang dipakai dan tidak otomatis sinkron antar perangkat. Ini sengaja dipilih agar tidak memerlukan server/database berbayar.

Untuk aplikasi toko multi-perangkat dengan akun yang benar-benar aman dan data sinkron, diperlukan backend/database. Bisa memakai free tier layanan tertentu, tetapi kuota/ketentuannya dapat berubah dan tidak dapat dijamin selamanya gratis.

Sebelum dipakai untuk bisnis sungguhan, ganti akun demo dan gunakan backend autentikasi yang aman jika sistem akan diakses banyak perangkat.
